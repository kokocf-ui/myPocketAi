// Pocket AI Europe Slim: licensed federated MOTIS-v6 relay.
// Node 22+, no npm dependencies, no stored timetable data, no logging of GPS.
import http from 'node:http';
import fs from 'node:fs';
import {timingSafeEqual} from 'node:crypto';

const CAP = 8 * 1024 * 1024;
const MAX_RESPONSE = 1_300_000;
const MAX_REQUESTS = 4;
const TIMEOUT_MS = 11_000;
const TTL_MS = 90_000;
const validPoint = (s) => {
  if (typeof s !== 'string' || !/^-?\d{1,2}(?:\.\d{1,7})?,-?\d{1,3}(?:\.\d{1,7})?$/.test(s)) return null;
  const [lat, lon] = s.split(',').map(Number);
  return Math.abs(lat) <= 90 && Math.abs(lon) <= 180 && Number.isFinite(lat) && Number.isFinite(lon) ? {lat, lon} : null;
};
const inside = (p, bbox) => p.lon >= bbox[0] && p.lat >= bbox[1] && p.lon <= bbox[2] && p.lat <= bbox[3];
const json = (code, body) => ({code, body: JSON.stringify(body)});
const secureEqual = (a, b) => {
  const aa = Buffer.from(String(a)), bb = Buffer.from(String(b));
  return aa.length > 0 && aa.length === bb.length && timingSafeEqual(aa, bb);
};
export function validateProviders(providers, {allowLocalTest=false} = {}) {
  if (!Array.isArray(providers) || providers.length > 20) throw Error('providers must be an array of at most 20');
  const ids = new Set();
  return providers.map(p => {
    if (typeof p !== 'object' || p === null || !/^[a-z0-9_-]{2,40}$/.test(p.id || '') || ids.has(p.id)) throw Error('bad or duplicate provider id');
    ids.add(p.id);
    const kind=p.kind||'motis';
    if(!['motis','local_gtfs'].includes(kind))throw Error('unsupported provider kind');
    const u = new URL(p.baseUrl);
    const internal = kind==='local_gtfs'&&u.protocol==='http:'&&u.hostname==='127.0.0.1'&&
       [8764,8765,8766].includes(Number(u.port));
    const localTest = allowLocalTest && u.protocol === 'http:' && u.hostname === '127.0.0.1';
    if (!(u.protocol === 'https:' || localTest || internal) || u.username || u.password || u.search || u.hash || u.pathname !== '/' ||
       u.hostname === 'api.transitous.org' || u.hostname === 'staging.api.transitous.org' ||
       (!localTest && !internal && (/^\d+\.\d+\.\d+\.\d+$/.test(u.hostname) || /^(localhost|127\.0\.0\.1|169\.254\.|10\.|192\.168\.)/.test(u.hostname))))
      throw Error('invalid or unlicensed upstream endpoint for '+p.id);
    if (!Array.isArray(p.bbox) || p.bbox.length !== 4 || !p.bbox.every(Number.isFinite) ||
       p.bbox[0] < -180 || p.bbox[2] > 180 || p.bbox[1] < -90 || p.bbox[3] > 90 ||
       p.bbox[0] >= p.bbox[2] || p.bbox[1] >= p.bbox[3]) throw Error('bad provider bbox for '+p.id);
    if (p.enabled !== true && p.enabled !== false) throw Error('enabled must be boolean');
    if (p.licenseApproved !== true && p.enabled === true) throw Error('enabled provider needs licenseApproved for '+p.id);
    if (p.tokenEnv != null && !/^EU_UPSTREAM_[A-Z0-9_]+$/.test(p.tokenEnv)) throw Error('invalid token env name');
    if (kind==='local_gtfs' && (!internal || !p.tokenEnv || !['GB','RO'].includes(p.country)))
      throw Error('local GTFS requires verified RO/GB host port, country and token');
    const countryCodes=p.countries||[];
    if(!Array.isArray(countryCodes)||countryCodes.length>49||countryCodes.some(c=>!/^[A-Z]{2}$/.test(c)))
      throw Error('bad countries list');
    return {id:p.id,kind,country:String(p.country||''),countries:countryCodes,
      baseUrl:u.origin,bbox:p.bbox,enabled:p.enabled,licenseApproved:p.licenseApproved === true,tokenEnv:p.tokenEnv||null};
  });
}
export function makeHandler({providers=[], accessToken, fetcher=fetch, clock=Date.now}={}) {
  if (typeof accessToken !== 'string' || accessToken.length < 24) throw Error('EU_RELAY_TOKEN must be at least 24 characters');
  const cache = new Map(); let cacheBytes = 0, active = 0;
  const cityRegions={
    RO:[['oradea',47.0465,21.9189,25000],['cluj',46.7712,23.6236,30000],
      ['iasi',47.1585,27.6014,27000],['bucharest',44.4268,26.1025,48000]]
  };
  const metres=(p,q)=>{const rad=Math.PI/180,x=(q.lat-p.lat)*rad,y=(q.lon-p.lon)*rad;
    const h=Math.sin(x/2)**2+Math.cos(p.lat*rad)*Math.cos(q.lat*rad)*Math.sin(y/2)**2;
    return 12742000*Math.atan2(Math.sqrt(h),Math.sqrt(Math.max(0,1-h)));};
  const validCoords=v=>v && v.latitude!=null&&v.longitude!=null&&
    Number.isFinite(+v.latitude)&&Number.isFinite(+v.longitude)&&Math.abs(+v.latitude)<=90&&Math.abs(+v.longitude)<=180;
  function localRegion(provider,from,to){
    if(provider.country==='RO'){
      const cities=cityRegions.RO;
      for(const [name,lat,lon,radius] of cities){
        const centre={lat,lon};
        if(metres(from,centre)<=radius&&metres(to,centre)<=radius)return name;
      }
      return null;
    }
    if(provider.country==='GB'&&from.lat>=49.9&&from.lat<=55.9&&to.lat>=49.9&&to.lat<=55.9&&
       from.lon>=-6.5&&from.lon<=2.1&&to.lon>=-6.5&&to.lon<=2.1&&metres(from,to)<=80000)return 'england';
    return null;
  }
  const localClock=(time,zone)=>{
    const p=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit',
      hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(new Date(time)).map(v=>[v.type,v.value]));
    return {date:p.year+'-'+p.month+'-'+p.day,afterHHMM:p.hour+':'+p.minute};
  };
  async function readBounded(res){
    if(!res.ok||Number(res.headers?.get?.('content-length'))>MAX_RESPONSE)return null;
    const reader=res.body?.getReader();if(!reader)return null;
    const chunks=[];let total=0;
    while(true){const {value,done}=await reader.read();if(done)break;
      total+=value.byteLength;if(total>MAX_RESPONSE){await reader.cancel();return null;}chunks.push(value);}
    try{return JSON.parse(Buffer.concat(chunks,total).toString('utf8'));}catch{return null;}
  }
  async function nationalPlan(request){
    if(request.method!=='POST')return json(405,{error:'post_only'});
    const b=request.body;
    if(!b||typeof b!=='object'||!validCoords(b.from)||!validCoords(b.to)||
       !/^[A-Z]{2}$/.test(String(b.country||'')))return json(400,{error:'invalid_national_route'});
    const departure=String(b.departureAt||'');
    if(departure&&!(/(?:Z|[+-]\d{2}:\d{2})$/.test(departure)&&Number.isFinite(Date.parse(departure))))
      return json(400,{error:'invalid_departure_time'});
    const when=departure||new Date(clock()).toISOString(),from={lat:+b.from.latitude,lon:+b.from.longitude},
      to={lat:+b.to.latitude,lon:+b.to.longitude};
    const local=providers.filter(p=>p.kind==='local_gtfs'&&p.enabled&&p.licenseApproved&&p.country===b.country&&
      inside(from,p.bbox)&&inside(to,p.bbox)&&p.tokenEnv&&process.env[p.tokenEnv]);
    const motis=providers.filter(p=>p.kind==='motis'&&p.enabled&&p.licenseApproved&&p.countries.includes(b.country)&&
      inside(from,p.bbox)&&inside(to,p.bbox));
    if(!local.length&&!motis.length)return json(503,{status:'no_licensed_national_provider',journeys:[]});
    if(active>=MAX_REQUESTS)return json(429,{status:'busy',journeys:[]});active++;
    try{
      const calls=local.slice(0,3).map(async p=>{
        const region=localRegion(p,from,to);
        if(!region)return null;
        const zone=p.country==='RO'?'Europe/Bucharest':'Europe/London';
        const parts=localClock(when,zone);
        const body=JSON.stringify({region,from:{latitude:from.lat,longitude:from.lon},
          to:{latitude:to.lat,longitude:to.lon},...parts,maxResults:Math.max(1,Math.min(6,+b.limit||4))});
        try{
          const res=await fetcher(p.baseUrl+'/v1/plan',{method:'POST',redirect:'error',
            headers:{Authorization:'Bearer '+process.env[p.tokenEnv],Accept:'application/json',
              'Content-Type':'application/json'},body,signal:AbortSignal.timeout(7000)});
          const value=await readBounded(res);
          if(value?.status==='route_only')return {status:'route_only',source:p.id,region,journeys:[],lines:value.journeys||[]};
          const journeys=Array.isArray(value?.journeys)?value.journeys.filter(j=>
            j?.scheduled===true&&j?.real_time===false&&Array.isArray(j.legs)&&j.legs.length>0&&
            j.legs.every(l=>Number.isFinite(Date.parse(l.departureTime))&&
              Number.isFinite(Date.parse(l.arrivalTime))&&Date.parse(l.arrivalTime)>Date.parse(l.departureTime))):[];
          return {status:journeys.length?'success':'no_verified_journeys',
            source:p.id,region,journeys};
        }catch{return null;}
      });
      // Both modes share one provider registry; MOTIS uses its own v6 payload.
      // It is not flattened into local GTFS rows, so no false transfer or fare.
      const callsMotis=motis.slice(0,2).map(async p=>{
        const params=new URLSearchParams({fromPlace:from.lat+','+from.lon,toPlace:to.lat+','+to.lon,
          time:when,language:String(b.language||'en').slice(0,5)});
        try{const h={Accept:'application/json'};if(p.tokenEnv&&process.env[p.tokenEnv])h.Authorization='Bearer '+process.env[p.tokenEnv];
          const res=await fetcher(p.baseUrl+'/api/v6/plan?'+params,{headers:h,redirect:'error',
            signal:AbortSignal.timeout(9000)});
          const value=await readBounded(res);
          const rows=Array.isArray(value?.itineraries)?value.itineraries.filter(j=>
            Array.isArray(j?.legs)&&j.legs.length&&Date.parse(j.endTime)>Date.parse(j.startTime)&&
            Date.parse(j.startTime)>=Date.parse(when)-60000).slice(0,6):[];
          return {status:rows.length?'success':'no_verified_journeys',source:p.id,
            format:'motis_v6',itineraries:rows,journeys:[]};}
        catch{return null;}
      });
      const results=(await Promise.all([...calls,...callsMotis])).filter(Boolean);
      const verified=results.filter(v=>v.status==='success');
      if(verified.length)return json(200,{status:'success',country:b.country,providers:verified});
      const lines=results.filter(v=>v.status==='route_only');
      if(lines.length)return json(200,{status:'route_only',country:b.country,
        scheduleVerified:false,providers:lines});
      return json(503,{status:'no_verified_journey',country:b.country,providers:[],journeys:[]});
    }finally{active--;}
  }
  function remember(k, v) {
    const size = Buffer.byteLength(v);
    if (size > CAP / 3) return;
    if (cache.has(k)) {cacheBytes -= cache.get(k).size; cache.delete(k);}
    cache.set(k, {content:v,size,until:clock()+TTL_MS}); cacheBytes += size;
    while (cacheBytes > CAP && cache.size) { const first=cache.keys().next().value; cacheBytes-=cache.get(first).size; cache.delete(first); }
  }
  return async function handle(request) {
    const path = new URL(request.url, 'http://127.0.0.1');
    if (path.pathname === '/healthz') return json(200, {status:'ready',
      configuredProviders:providers.filter(p=>p.enabled&&p.kind==='motis').length,
      configuredNationalProviders:providers.filter(p=>p.enabled&&p.kind==='local_gtfs').length,
      coverage:'upstream_dependent',localTimetableBytes:0});
    if (!['/api/v6/plan','/v1/national-plan'].includes(path.pathname)) return json(404,{error:'not_found'});
    const authorization = String(request.headers?.authorization || '').replace(/^Bearer /i,'');
    if (!secureEqual(authorization,accessToken)) return json(401,{error:'unauthorized'});
    if(path.pathname==='/v1/national-plan')return nationalPlan(request);
    if (request.method !== 'GET') return json(405,{error:'get_only'});
    if (path.search.length > 1300) return json(400,{error:'query_too_large'});
    const start=validPoint(path.searchParams.get('fromPlace')), dest=validPoint(path.searchParams.get('toPlace'));
    const time=path.searchParams.get('time');
    if (!start || !dest || (time && (!/^\d{4}-\d\d-\d\dT\d\d:\d\d/.test(time) || !Number.isFinite(Date.parse(time)) || !/(?:Z|[+-]\d\d:\d\d)$/.test(time))))
      return json(400,{error:'invalid_origin_destination_or_time'});
    const matching=providers.filter(p=>p.kind==='motis'&&p.enabled&&p.licenseApproved&&inside(start,p.bbox)&&inside(dest,p.bbox)).slice(0,3);
    if (!matching.length) return json(503,{error:'no_licensed_provider_for_corridor',itineraries:[]});
    const keep = ['fromPlace','toPlace','time','language','minTransferTime','searchWindow','detailedTransfers','numItineraries'];
    const params=new URLSearchParams(); for(const k of keep){const v=path.searchParams.get(k);if(v!==null)params.set(k,v);}
    params.set('numItineraries',String(Math.max(1,Math.min(8,Number(params.get('numItineraries'))||6))));
    const key=matching.map(p=>p.id).join(',')+'|'+params.toString();
    const cached=cache.get(key);
    if (cached && cached.until > clock()) return {code:200,body:cached.content};
    if (cached) {cacheBytes-=cached.size;cache.delete(key);}
    if (active>=MAX_REQUESTS) return json(429,{error:'busy'});
    active++;
    try{
      const responses=await Promise.all(matching.map(async p=>{
        const headers={Accept:'application/json','User-Agent':'PocketAI-Europe-Slim/1.0'};
        const upstreamKey=p.tokenEnv?process.env[p.tokenEnv]:null;
        if(p.tokenEnv&&!upstreamKey)return null;
        if(upstreamKey)headers.Authorization='Bearer '+upstreamKey;
        const u=p.baseUrl+'/api/v6/plan?'+params;
        try{
          const res=await fetcher(u,{headers,redirect:'error',signal:AbortSignal.timeout(TIMEOUT_MS)});
          if(!res.ok || Number(res.headers?.get?.('content-length'))>MAX_RESPONSE) return null;
          const reader=res.body?.getReader(); if(!reader)return null;
          const chunks=[];let total=0;
          while(true){const {value:piece,done}=await reader.read(); if(done)break;
           total+=piece.byteLength; if(total>MAX_RESPONSE){await reader.cancel();return null;}
           chunks.push(piece);
          }
          const body=Buffer.concat(chunks,total).toString('utf8');
          const value=JSON.parse(body);
          return Array.isArray(value?.itineraries)?value.itineraries.filter(j=>
            Array.isArray(j?.legs)&&j.legs.length>0&&Number.isFinite(Date.parse(j.startTime))&&Number.isFinite(Date.parse(j.endTime))) : null;
        }catch{return null;}
      }));
      const routes=responses.flatMap(x=>x||[]).filter(j=>
        j.legs.length<=30&&Date.parse(j.endTime)>Date.parse(j.startTime) &&
        (!time || Date.parse(j.startTime)>=Date.parse(time)-60000));
      // Do not splice different providers' routes: each itinerary stays whole.
      const known=new Set(), selected=[];
      for (const j of routes.sort((a,b)=>Date.parse(a.endTime)-Date.parse(b.endTime))) {
        const signature=[j.startTime,j.endTime,j.legs.map(l=>[l.mode,l.startTime,l.endTime].join(':')).join('|')].join(':');
        if (known.has(signature)) continue; known.add(signature);selected.push(j); if(selected.length>=8)break;
      }
      if (!selected.length) return json(503,{error:'no_verified_itinerary_from_upstream',itineraries:[]});
      const response=JSON.stringify({itineraries:selected});
      remember(key,response);
      return {code:200,body:response};
    }finally {active--;}
  };
}
export function start({configFile=process.env.EU_RELAY_PROVIDERS_FILE||'/etc/pocketai-europe-slim.providers.json'}={}) {
  const providers=validateProviders(JSON.parse(fs.readFileSync(configFile,'utf8')));
  const handle=makeHandler({providers,accessToken:process.env.EU_RELAY_TOKEN});
  const server=http.createServer(async(req,res)=>{
    let out;try{
      if(req.url?.startsWith('/v1/national-plan')&&req.method==='POST'){
        const chunks=[];let bytes=0;
        for await(const chunk of req){bytes+=chunk.length;if(bytes>2048){out=json(413,{error:'too_large'});break;}chunks.push(chunk);}
        if(!out){let body;try{body=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{body=null;}
          out=await handle({url:req.url,method:req.method,headers:req.headers,body});}
      }else out=await handle(req);
    }catch{out=json(500,{error:'internal_error'});}
    res.writeHead(out.code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
    res.end(out.body);
  });
  server.requestTimeout=15_000;server.headersTimeout=5_000;
  const port=Number(process.env.EU_RELAY_PORT||8767);
  server.listen(port,'127.0.0.1',()=>process.stdout.write('europe-slim-ready localhost:'+port+'\n'));
  return server;
}
if (process.argv[1] && import.meta.url === new URL('file://'+process.argv[1]).href) start();
