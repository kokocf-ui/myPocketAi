// Pocket AI Europe Slim: licensed federated MOTIS-v6 relay.
// Node 22+, no npm dependencies, no stored timetable data, no logging of GPS.
import http from 'node:http';
import fs from 'node:fs';
import {timingSafeEqual} from 'node:crypto';

const CAP = 8 * 1024 * 1024;
const MAX_RESPONSE = 1_300_000;
const MAX_REQUESTS = 4;
const TIMEOUT_MS = 11_000;
const TTL_MS = 90_000;
const validPoint = (s) => {
  if (typeof s !== 'string' || !/^-?\d{1,2}(?:\.\d{1,7})?,-?\d{1,3}(?:\.\d{1,7})?$/.test(s)) return null;
  const [lat, lon] = s.split(',').map(Number);
  return Math.abs(lat) <= 90 && Math.abs(lon) <= 180 && Number.isFinite(lat) && Number.isFinite(lon) ? {lat, lon} : null;
};
const inside = (p, bbox) => p.lon >= bbox[0] && p.lat >= bbox[1] && p.lon <= bbox[2] && p.lat <= bbox[3];
const json = (code, body) => ({code, body: JSON.stringify(body)});
const secureEqual = (a, b) => {
  const aa = Buffer.from(String(a)), bb = Buffer.from(String(b));
  return aa.length > 0 && aa.length === bb.length && timingSafeEqual(aa, bb);
};
export function validateProviders(providers, {allowLocalTest=false} = {}) {
  if (!Array.isArray(providers) || providers.length > 20) throw Error('providers must be an array of at most 20');
  const ids = new Set();
  return providers.map(p => {
    if (typeof p !== 'object' || p === null || !/^[a-z0-9_-]{2,40}$/.test(p.id || '') || ids.has(p.id)) throw Error('bad or duplicate provider id');
    ids.add(p.id);
    const u = new URL(p.baseUrl);
    const localTest = allowLocalTest && u.protocol === 'http:' && u.hostname === '127.0.0.1';
    if (!(u.protocol === 'https:' || localTest) || u.username || u.password || u.search || u.hash || u.pathname !== '/' ||
       u.hostname === 'api.transitous.org' || u.hostname === 'staging.api.transitous.org' ||
       (!localTest && (/^\d+\.\d+\.\d+\.\d+$/.test(u.hostname) || /^(localhost|127\.0\.0\.1|169\.254\.|10\.|192\.168\.)/.test(u.hostname))))
      throw Error('invalid or unlicensed upstream endpoint for '+p.id);
    if (!Array.isArray(p.bbox) || p.bbox.length !== 4 || !p.bbox.every(Number.isFinite) ||
       p.bbox[0] < -180 || p.bbox[2] > 180 || p.bbox[1] < -90 || p.bbox[3] > 90 ||
       p.bbox[0] >= p.bbox[2] || p.bbox[1] >= p.bbox[3]) throw Error('bad provider bbox for '+p.id);
    if (p.enabled !== true && p.enabled !== false) throw Error('enabled must be boolean');
    if (p.licenseApproved !== true && p.enabled === true) throw Error('enabled provider needs licenseApproved for '+p.id);
    if (p.tokenEnv != null && !/^EU_UPSTREAM_[A-Z0-9_]+$/.test(p.tokenEnv)) throw Error('invalid token env name');
    return {id:p.id, baseUrl:u.origin, bbox:p.bbox, enabled:p.enabled, licenseApproved:p.licenseApproved === true, tokenEnv:p.tokenEnv || null};
  });
}
export function makeHandler({providers=[], accessToken, fetcher=fetch, clock=Date.now}={}) {
  if (typeof accessToken !== 'string' || accessToken.length < 24) throw Error('EU_RELAY_TOKEN must be at least 24 characters');
  const cache = new Map(); let cacheBytes = 0, active = 0;
  function remember(k, v) {
    const size = Buffer.byteLength(v);
    if (size > CAP / 3) return;
    if (cache.has(k)) {cacheBytes -= cache.get(k).size; cache.delete(k);}
    cache.set(k, {content:v,size,until:clock()+TTL_MS}); cacheBytes += size;
    while (cacheBytes > CAP && cache.size) { const first=cache.keys().next().value; cacheBytes-=cache.get(first).size; cache.delete(first); }
  }
  return async function handle(request) {
    const path = new URL(request.url, 'http://127.0.0.1');
    if (path.pathname === '/healthz') return json(200, {status:'ready',configuredProviders:providers.filter(p=>p.enabled).length,coverage:'upstream_dependent',localTimetableBytes:0});
    if (path.pathname !== '/api/v6/plan') return json(404,{error:'not_found'});
    const authorization = String(request.headers?.authorization || '').replace(/^Bearer /i,'');
    if (!secureEqual(authorization,accessToken)) return json(401,{error:'unauthorized'});
    if (request.method !== 'GET') return json(405,{error:'get_only'});
    if (path.search.length > 1300) return json(400,{error:'query_too_large'});
    const start=validPoint(path.searchParams.get('fromPlace')), dest=validPoint(path.searchParams.get('toPlace'));
    const time=path.searchParams.get('time');
    if (!start || !dest || (time && (!/^\d{4}-\d\d-\d\dT\d\d:\d\d/.test(time) || !Number.isFinite(Date.parse(time)) || !/(?:Z|[+-]\d\d:\d\d)$/.test(time))))
      return json(400,{error:'invalid_origin_destination_or_time'});
    const matching=providers.filter(p=>p.enabled&&p.licenseApproved&&inside(start,p.bbox)&&inside(dest,p.bbox)).slice(0,3);
    if (!matching.length) return json(503,{error:'no_licensed_provider_for_corridor',itineraries:[]});
    const keep = ['fromPlace','toPlace','time','language','minTransferTime','searchWindow','detailedTransfers','numItineraries'];
    const params=new URLSearchParams(); for(const k of keep){const v=path.searchParams.get(k);if(v!==null)params.set(k,v);}
    params.set('numItineraries',String(Math.max(1,Math.min(8,Number(params.get('numItineraries'))||6))));
    const key=matching.map(p=>p.id).join(',')+'|'+params.toString();
    const cached=cache.get(key);
    if (cached && cached.until > clock()) return {code:200,body:cached.content};
    if (cached) {cacheBytes-=cached.size;cache.delete(key);}
    if (active>=MAX_REQUESTS) return json(429,{error:'busy'});
    active++;
    try{
      const responses=await Promise.all(matching.map(async p=>{
        const headers={Accept:'application/json','User-Agent':'PocketAI-Europe-Slim/1.0'};
        const upstreamKey=p.tokenEnv?process.env[p.tokenEnv]:null;
        if(p.tokenEnv&&!upstreamKey)return null;
        if(upstreamKey)headers.Authorization='Bearer '+upstreamKey;
        const u=p.baseUrl+'/api/v6/plan?'+params;
        try{
          const res=await fetcher(u,{headers,redirect:'error',signal:AbortSignal.timeout(TIMEOUT_MS)});
          if(!res.ok || Number(res.headers?.get?.('content-length'))>MAX_RESPONSE) return null;
          const reader=res.body?.getReader(); if(!reader)return null;
          const chunks=[];let total=0;
          while(true){const {value:piece,done}=await reader.read(); if(done)break;
           total+=piece.byteLength; if(total>MAX_RESPONSE){await reader.cancel();return null;}
           chunks.push(piece);
          }
          const body=Buffer.concat(chunks,total).toString('utf8');
          const value=JSON.parse(body);
          return Array.isArray(value?.itineraries)?value.itineraries.filter(j=>
            Array.isArray(j?.legs)&&j.legs.length>0&&Number.isFinite(Date.parse(j.startTime))&&Number.isFinite(Date.parse(j.endTime))) : null;
        }catch{return null;}
      }));
      const routes=responses.flatMap(x=>x||[]).filter(j=>
        j.legs.length<=30&&Date.parse(j.endTime)>Date.parse(j.startTime) &&
        (!time || Date.parse(j.startTime)>=Date.parse(time)-60000));
      // Do not splice different providers' routes: each itinerary stays whole.
      const known=new Set(), selected=[];
      for (const j of routes.sort((a,b)=>Date.parse(a.endTime)-Date.parse(b.endTime))) {
        const signature=[j.startTime,j.endTime,j.legs.map(l=>[l.mode,l.startTime,l.endTime].join(':')).join('|')].join(':');
        if (known.has(signature)) continue; known.add(signature);selected.push(j); if(selected.length>=8)break;
      }
      if (!selected.length) return json(503,{error:'no_verified_itinerary_from_upstream',itineraries:[]});
      const response=JSON.stringify({itineraries:selected});
      remember(key,response);
      return {code:200,body:response};
    }finally {active--;}
  };
}
export function start({configFile=process.env.EU_RELAY_PROVIDERS_FILE||'/etc/pocketai-europe-slim.providers.json'}={}) {
  const providers=validateProviders(JSON.parse(fs.readFileSync(configFile,'utf8')));
  const handle=makeHandler({providers,accessToken:process.env.EU_RELAY_TOKEN});
  const server=http.createServer(async(req,res)=>{
    let out;try{out=await handle(req);}catch{out=json(500,{error:'internal_error'});}
    res.writeHead(out.code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
    res.end(out.body);
  });
  server.requestTimeout=15_000;server.headersTimeout=5_000;
  const port=Number(process.env.EU_RELAY_PORT||8767);
  server.listen(port,'127.0.0.1',()=>process.stdout.write('europe-slim-ready localhost:'+port+'\n'));
  return server;
}
if (process.argv[1] && import.meta.url === new URL('file://'+process.argv[1]).href) start();
